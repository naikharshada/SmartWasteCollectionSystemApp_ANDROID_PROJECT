package com.example.smartwastecollectionsystem.ui.localuser;

public interface OnRequestPermissionsResult {
}
